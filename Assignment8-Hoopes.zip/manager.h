// Name: John Hoopes
// Recitation 110: Monika Tak
// Homework Assignment 8

#ifndef MANAGER_H
#define MANAGER_H

#include <iostream>
using namespace std;

class manager {
  public:
    // Constructor / Destructor Methods
    Manager();
    Manager(string nom);
    ~Voter();
    void setName(string nom);
    string getName();
    void setPassword(string password);
    bool checkPassword();
    void readFile(string input_file); // ?? read!
    int inputSalary();

    // Data members
    int manager_salary;
    string manager_name;
  private:
    string manager_password;
}
